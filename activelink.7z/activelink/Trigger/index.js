const express = require('express');
const { exec } = require('child_process');
const app = express();

const SECRET = "saymyname-heisenberg";

app.use(express.json());

app.post('/trigger', (req, res) => {
    if (req.body.secret !== SECRET) return res.status(403).send("Forbidden");

    exec('/home/atozvm/Desktop/activelink/run_active.sh', (err, stdout, stderr) => {
        if (err) return res.status(500).send(stderr);
        res.send("✅ Script executed!");
    });
});

app.post('/stop', (req, res) => {
    console.log("📩 /stop endpoint hit");

    const receivedSecret = req.body.secret;
    console.log("🔑 Received secret:", receivedSecret);

    if (receivedSecret !== SECRET) {
        console.warn("❌ Unauthorized attempt with wrong secret");
        return res.status(403).send("Forbidden");
    }

    console.log("✅ Secret verified. Running stop_instanly.sh...");

    exec('/home/atozvm/Desktop/password_reset/stop_password.sh', (err, stdout, stderr) => {
        if (err) {
            console.error("❗ Error executing stop_instanly.sh:", err);
            return res.status(500).send(stderr);
        }

        console.log("🛑 stop_instanly.sh executed successfully.");
        console.log("STDOUT:", stdout);
        console.log("STDERR:", stderr);
        res.send("🛑 Script stopped!");
    });
});



app.listen(8085, () => console.log("🚀 Webhook server running on port 8085"));
