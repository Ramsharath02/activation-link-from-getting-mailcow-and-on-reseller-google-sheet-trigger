#!/bin/bash

# Find and kill the instantlyGS.py process
pkill -f password.py

