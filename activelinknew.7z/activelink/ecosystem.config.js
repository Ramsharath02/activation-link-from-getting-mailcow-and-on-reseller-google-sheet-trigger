module.exports = {
  apps: [
    {
      name: 'passwordreset',
      script: 'python3',
      args: ['passwordreset.py', '--serve'],
      cwd: '/home/atozvm2/Desktop/activelink',
      interpreter: 'none',
      watch: false,
      autorestart: true,
      max_restarts: 20,
      restart_delay: 3000,
      time: true,
      env: {
        PYTHONUNBUFFERED: '1',
        PORT: '6969'
      },
      error_file: '/home/atozvm2/Desktop/activelink/logs/passwordreset-error.log',
      out_file: '/home/atozvm2/Desktop/activelink/logs/passwordreset-out.log',
      log_file: '/home/atozvm2/Desktop/activelink/logs/passwordreset-combined.log',
      combine_logs: true,
      instances: 1,
      exec_mode: 'fork'
    }
  ]
};
