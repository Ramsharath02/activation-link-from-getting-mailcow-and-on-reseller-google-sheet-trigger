#!/bin/bash
gnome-terminal -- bash -c "python3 ~/Desktop/activelink/node.js; exec bash"
