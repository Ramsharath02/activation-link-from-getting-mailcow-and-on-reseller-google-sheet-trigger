import { ImapFlow } from "imapflow";
import { simpleParser } from "mailparser";
import fetch from "node-fetch";


const APPSCRIPT_URL ="https://script.google.com/macros/s/AKfycbznSJk_88e9czJODBDEXamv8GK4-AOmFRVn15qXIMpUhdlexY0MSmDn2cM7uoqjpUg/exec";
// Google Sheet URL for password reset data
const GOOGLE_SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1FwKV4qlV00rcwfjYx4Nhw31Pkd5HxnhJglWVr9ieSQc/edit?usp=sharing"

const domainRegex = /Action required for your domain\s*<a[^>]*>([^<]+)<\/a>/i;
const linkRegex = /Click <a href="?([^"\s>]+)"?[^>]*>here<\/a>/i;

// Gmail-like filter components
const GOOGLE_SENDER = "workspace-noreply@google.com";
const SUBJECT_REGEX = /You[’']ve signed up for a Google product/i;

// Build a CSV export URL from a share/edit link
function csvExportUrlFromShareLink(shareUrl) {
  try {
    const idMatch = shareUrl.match(/\/spreadsheets\/d\/([^\/]+)/);
    const id = idMatch ? idMatch[1] : null;
    // Try to read gid from query, default to 0
    const gidMatch = shareUrl.match(/[?&]gid=(\d+)/);
    const gid = gidMatch ? gidMatch[1] : "0";
    if (!id) return null;
    return `https://docs.google.com/spreadsheets/d/${id}/export?format=csv&gid=${gid}`;
  } catch (_) {
    return null;
  }
}

function parseCsv(text) {
  const rows = [];
  let cur = "";
  let row = [];
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { // escaped quote
          cur += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cur += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        row.push(cur);
        cur = "";
      } else if (ch === '\r') {
        // skip
      } else if (ch === '\n') {
        row.push(cur);
        rows.push(row);
        row = [];
        cur = "";
      } else {
        cur += ch;
      }
    }
  }
  // push last value
  row.push(cur);
  rows.push(row);
  return rows;
}

// Fetch domain list in row order, filtered where activation_url is empty
async function fetchDomainListOrdered() {
  try {
    const exportUrl = csvExportUrlFromShareLink(GOOGLE_SHEET_CSV_URL);
    if (!exportUrl) throw new Error("Invalid sheet URL");
    const res = await fetch(exportUrl);
    if (!res.ok) throw new Error(`CSV fetch failed: ${res.status}`);
    const csv = await res.text();
    const rows = parseCsv(csv);
    if (!rows.length) return [];
    const normalize = (v) => String(v || "").replace(/^\ufeff/, "").trim();
    const headers = rows[0].map(normalize);
    const domainIdx = headers.indexOf("Domain Name");
    const activationIdx = headers.indexOf("activation_url");
    if (domainIdx === -1) throw new Error('Missing header "Domain Name"');
    const out = [];
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const domain = normalize(row[domainIdx]);
      const activationUrl = activationIdx === -1 ? "" : normalize(row[activationIdx]);
      if (domain && !activationUrl) {
        out.push(domain);
      }
    }
    return out;
  } catch (err) {
    console.error("❌ Failed to fetch ordered domain list from CSV:", err.message);
    return [];
  }
}

async function fetchDomainsFromSheet() {
  try {
    const ordered = await fetchDomainListOrdered();
    return new Set(ordered.map((d) => d.trim().toLowerCase()));
  } catch (err) {
    console.error("❌ Failed to build domain set from CSV:", err.message);
    return new Set();
  }
}

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

let isRunning = false;

async function processEmails() {
  if (isRunning) {
    console.log("⏳ Skipping: previous run still active...");
    return;
  }
  isRunning = true;

  const client = new ImapFlow({
    host: "mail.mytapleadspro.co",
    port: 993,
    secure: true,
    auth: {
      user: "mailme@mytapleadspro.co",
      pass: "Atoz@123",
    },
    logger: false,
  });

  try {
    // Fetch domains from the Sheet first (ordered + set for quick lookups)
    const domainListOrdered = await fetchDomainListOrdered();
    const allowedDomains = new Set(
      domainListOrdered.map((d) => d.trim().toLowerCase())
    );

    await client.connect();
    const lock = await client.getMailboxLock("INBOX");

    try {
      // fetch mails from Google Workspace system sender
      let messages = await client.search({ from: GOOGLE_SENDER });
      console.log(`📩 Found ${messages.length} total message(s)`);

      // Build domain -> activationLink map using 10-concurrency while reading emails
      const domainToLink = new Map();

      for (const group of chunk(messages, 10)) {
        await Promise.all(
          group.map(async (uid) => {
            try {
              const msg = await client.fetchOne(uid, { source: true });
              if (!msg?.source) return;
              const parsed = await simpleParser(msg.source);
              const subject = parsed.subject || "";
              if (!SUBJECT_REGEX.test(subject)) return;
              const htmlContent = parsed.html || parsed.textAsHtml || parsed.text || "";
              const domainMatch = htmlContent.match(domainRegex);
              const foundDomain = domainMatch ? domainMatch[1].trim() : null;
              const linkMatch = htmlContent.match(linkRegex);
              const activationLink = linkMatch ? linkMatch[1] : null;
              if (!foundDomain || !activationLink) return;
              const normalized = foundDomain.trim().toLowerCase();
              if (!allowedDomains.has(normalized)) return; // Only keep domains that appear in sheet
              if (!domainToLink.has(normalized)) {
                domainToLink.set(normalized, activationLink);
              }
            } catch (e) {
              console.log(`⚠️ Failed parsing UID ${uid}:`, e.message);
            }
          })
        );
      }

      console.log(`🗺️ Built activation map for ${domainToLink.size} domain(s)`);

      // Process the domain list in row order, batches of 10, concurrency 10
      for (const group of chunk(domainListOrdered, 10)) {
        await Promise.all(
          group.map(async (domain) => {
            const normalized = domain.trim().toLowerCase();
            const activationLink = domainToLink.get(normalized);
            if (!activationLink) {
              console.log(`❌ No activation link found for ${domain}`);
              return;
            }
            try {
              await fetch(activationLink).catch(() =>
                console.log("⚠️ Could not visit activation link directly")
              );

				const response = await fetch(APPSCRIPT_URL, {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify({
					  domain: domain,
					  activationLink: activationLink,
					}),
				});
              console.log("✅ Sheet updated:", await response.text());
            } catch (err) {
              console.log(`⚠️ Failed to update sheet for ${domain}:`, err.message);
            }
          })
        );
      }
    } finally {
      await lock.release();
    }

    await client.logout();
  } catch (err) {
    console.error("❌ Email processing error:", err.message);
  } finally {
    isRunning = false;
  }
}

processEmails();
