#!/usr/bin/env python3

import requests
import csv
import io
import time
import threading
import imaplib
import email
from email.header import decode_header, make_header
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import urllib.parse as urlparse
import argparse
import os

# Google Sheet URL for password reset data
GOOGLE_SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1FwKV4qlV00rcwfjYx4Nhw31Pkd5HxnhJglWVr9ieSQc/edit?usp=sharing"

# Mailcow IMAP configuration (same as node.js)
IMAP_HOST = "mail.mytapleadspro.co"
IMAP_PORT = 993
IMAP_USER = "mailme@mytapleadspro.co"
IMAP_PASS = "Atoz@123"

# Google Workspace sender and subject filter
GOOGLE_SENDER = "workspace-noreply@google.com"
SUBJECT_PATTERN = re.compile(r"You[’']ve signed up for a Google product", re.I)

# Regex to extract domain and link from HTML
DOMAIN_REGEX = re.compile(r"Action required for your domain\s*<a[^>]*>([^<]+)</a>", re.I)
LINK_REGEX = re.compile(r'Click <a href="?([^"\s>]+)"?[^>]*>here</a>', re.I)

# Apps Script endpoint that updates activation_url by domain
APPS_SCRIPT_ACTIVATION_URL = "https://script.google.com/macros/s/AKfycbznSJk_88e9czJODBDEXamv8GK4-AOmFRVn15qXIMpUhdlexY0MSmDn2cM7uoqjpUg/exec"

# Thread locks for thread safety
sheet_update_lock = threading.Lock()
data_processing_lock = threading.Lock()

# Trigger server state
_job_running = False
_job_lock = threading.Lock()
_http_server = None

def read_google_sheet():
    """Read data from Google Sheet, apply filters including vm='v1', and return header and filtered rows"""
    try:
        # Convert the sharing URL to CSV export URL
        csv_url = GOOGLE_SHEET_CSV_URL.replace('/edit?usp=sharing', '/export?format=csv&gid=0')
        
        headers = {
            'Accept': 'text/csv',
            'Cache-Control': 'no-cache'
        }
        response = requests.get(csv_url, headers=headers, timeout=30)
        response.raise_for_status()
        
        csv_file = io.StringIO(response.text)
        csv_reader = list(csv.reader(csv_file))
        
        if not csv_reader:
            print("No data found in the Google Sheet")
            return None, None
            
        header = csv_reader[0]
        rows = csv_reader[1:]
        
        print(f"Header: {header}")
        print(f"Found {len(rows)} rows of data before filtering")
        
        # Find column indices for filtering
        order_status_index = None
        setup_admin_index = None
        activation_url_index = None
        status_index = None
        password_index = None
        domain_index = 0  # Assuming domain is in the first column
        vm_index = None
        
        for i, col_name in enumerate(header):
            if 'order_status' in col_name.lower():
                order_status_index = i
            elif 'setup_admin' in col_name.lower():
                setup_admin_index = i
            elif 'activation' in col_name.lower() and 'url' in col_name.lower():
                activation_url_index = i
            elif 'status' in col_name.lower() and 'order' not in col_name.lower():
                status_index = i
            elif 'password' in col_name.lower() and 'admin' in col_name.lower():
                password_index = i
            elif 'vm' in col_name.lower():
                vm_index = i
        
        # Validate required columns
        required_columns = [
            (order_status_index, "order_status"),
            (setup_admin_index, "setup_admin"),
            (activation_url_index, "activation_url"),
            (status_index, "status"),
            (password_index, "admin_password"),
            (vm_index, "vm")
        ]
        
        for index, col_name in required_columns:
            if index is None:
                print(f"Could not find '{col_name}' column in header: {header}")
                return None, None
        
        # Filter rows based on conditions including vm='v1'
        # Note: activation_url can be empty; we'll fetch it from IMAP if missing.
        filtered_rows = [
            row for row in rows
            if (len(row) > max(order_status_index, setup_admin_index, activation_url_index, status_index, password_index, vm_index) and
                row[order_status_index].lower() == 'success' and
                row[setup_admin_index].lower() == 'success' and
                (row[status_index].strip() == '' or row[status_index].lower() == 'empty') and
                row[vm_index].strip() == 'v2')
        ]
        
        print(f"After filtering (including vm='v2'): {len(filtered_rows)} rows remain")
        
        # Print fetched and filtered data (summary only)
        print("\n📋 Fetched rows ready to process:")
        print("=" * 50)
        print(f"Total rows: {len(filtered_rows)}")
        
        return header, filtered_rows
        
    except Exception as e:
        print(f"Error reading Google Sheet: {e}")
        return None, None

def fetch_domains_without_activation(limit=10):
    """Return domains (row order) where activation_url is empty. Limit to first N rows."""
    try:
        csv_url = GOOGLE_SHEET_CSV_URL.replace('/edit?usp=sharing', '/export?format=csv&gid=0')
        headers = { 'Accept': 'text/csv', 'Cache-Control': 'no-cache' }
        response = requests.get(csv_url, headers=headers, timeout=30)
        response.raise_for_status()

        csv_file = io.StringIO(response.text)
        csv_reader = list(csv.reader(csv_file))
        if not csv_reader:
            return []

        header = [h.replace('\ufeff', '').strip() for h in csv_reader[0]]
        rows = csv_reader[1:]

        domain_idx = None
        activation_idx = None
        for i, col_name in enumerate(header):
            name = col_name.strip()
            if name.lower() == 'domain name':
                domain_idx = i
            elif name.lower() == 'activation_url':
                activation_idx = i

        if domain_idx is None or activation_idx is None:
            return []

        domains = []
        for row in rows:
            domain = (row[domain_idx] if len(row) > domain_idx else '').strip()
            activation = (row[activation_idx] if len(row) > activation_idx else '').strip()
            if domain and activation == '':
                domains.append(domain)
            if limit and len(domains) >= limit:
                break
        return domains
    except Exception as e:
        print(f"❌ Error fetching domains without activation: {e}")
        return []

def imap_build_domain_link_map(allowed_domains_lower):
    """Scan Mailcow inbox and return {domain_lower: activation_link} for allowed domains."""
    domain_to_link = {}
    try:
        M = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        M.login(IMAP_USER, IMAP_PASS)
        M.select('INBOX')

        typ, data = M.search(None, 'FROM', f'"{GOOGLE_SENDER}"')
        if typ != 'OK':
            print("⚠️  IMAP search failed")
            M.logout()
            return domain_to_link

        ids = data[0].split()
        print(f"📩 IMAP: Found {len(ids)} message(s) from {GOOGLE_SENDER}")

        for uid in ids:
            try:
                typ, msg_data = M.fetch(uid, '(RFC822)')
                if typ != 'OK' or not msg_data or not msg_data[0]:
                    continue
                raw = msg_data[0][1]
                msg = email.message_from_bytes(raw)
                # Subject filter
                raw_subject = msg.get('Subject', '')
                subject = str(make_header(decode_header(raw_subject)))
                if not SUBJECT_PATTERN.search(subject or ''):
                    continue

                # Extract HTML
                html_content = ''
                if msg.is_multipart():
                    for part in msg.walk():
                        ctype = part.get_content_type()
                        if ctype == 'text/html':
                            try:
                                html_content = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', errors='ignore')
                                break
                            except Exception:
                                continue
                else:
                    if msg.get_content_type() == 'text/html':
                        html_content = msg.get_payload(decode=True).decode(msg.get_content_charset() or 'utf-8', errors='ignore')
                    elif msg.get_content_type() == 'text/plain':
                        html_content = msg.get_payload(decode=True).decode(msg.get_content_charset() or 'utf-8', errors='ignore')

                if not html_content:
                    continue

                dmatch = DOMAIN_REGEX.search(html_content)
                lmatch = LINK_REGEX.search(html_content)
                if not dmatch or not lmatch:
                    continue

                found_domain = dmatch.group(1).strip()
                activation_link = lmatch.group(1)
                normalized = found_domain.lower()
                if normalized in allowed_domains_lower and normalized not in domain_to_link:
                    domain_to_link[normalized] = activation_link
            except Exception:
                continue

        M.close()
        M.logout()
    except Exception as e:
        print(f"❌ IMAP error: {e}")
    return domain_to_link

def update_activation_url_in_sheet(domain, activation_link):
    """POST to Apps Script to write activation_url for the given domain."""
    try:
        payload = {"domain": domain, "activationLink": activation_link}
        r = requests.post(APPS_SCRIPT_ACTIVATION_URL, json=payload, timeout=30)
        if r.status_code == 200:
            print(f"✅ Updated activation_url for {domain}")
            return True
        print(f"⚠️  Failed to update activation_url for {domain}: {r.status_code}")
        return False
    except Exception as e:
        print(f"❌ Error updating activation_url for {domain}: {e}")
        return False

def open_imap_session():
    try:
        M = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        M.login(IMAP_USER, IMAP_PASS)
        M.select('INBOX')
        return M
    except Exception as e:
        print(f"❌ Could not open IMAP session: {e}")
        return None

def close_imap_session(M):
    if not M:
        return
    try:
        M.close()
    except Exception:
        pass
    try:
        M.logout()
    except Exception:
        pass

def imap_find_activation_link_for_domain(M, domain):
    """Search the Mailcow inbox for the given domain and return the activation link, or None."""
    if not M:
        return None
    try:
        typ, data = M.search(None, 'FROM', f'"{GOOGLE_SENDER}"', 'SUBJECT', '"Google product"')
        if typ != 'OK':
            return None
        ids = data[0].split()
        # Search newest to oldest to find the most recent invite
        for uid in reversed(ids):
            typ, msg_data = M.fetch(uid, '(RFC822)')
            if typ != 'OK' or not msg_data or not msg_data[0]:
                continue
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)
            subject = str(make_header(decode_header(msg.get('Subject', ''))))
            if not SUBJECT_PATTERN.search(subject or ''):
                continue
            html_content = ''
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == 'text/html':
                        try:
                            html_content = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', errors='ignore')
                            break
                        except Exception:
                            continue
            else:
                if msg.get_content_type() in ('text/html', 'text/plain'):
                    html_content = msg.get_payload(decode=True).decode(msg.get_content_charset() or 'utf-8', errors='ignore')

            if not html_content:
                continue

            dmatch = DOMAIN_REGEX.search(html_content)
            lmatch = LINK_REGEX.search(html_content)
            if not dmatch or not lmatch:
                continue
            found_domain = dmatch.group(1).strip().lower()
            if found_domain == domain.strip().lower():
                return lmatch.group(1)
        return None
    except Exception:
        return None

def imap_find_activation_link_for_domain_single(domain):
    """Helper that opens its own IMAP session to find a domain's activation link."""
    M = open_imap_session()
    try:
        return imap_find_activation_link_for_domain(M, domain)
    finally:
        close_imap_session(M)

def extract_password_and_url(row, header):
    """Extract Admin Password and activation_url from a row"""
    try:
        # Find column indices
        password_index = None
        url_index = None
        
        for i, col_name in enumerate(header):
            if 'password' in col_name.lower() and 'admin' in col_name.lower():
                password_index = i
            elif 'activation' in col_name.lower() and 'url' in col_name.lower():
                url_index = i
        
        if password_index is None or url_index is None:
            print(f"Could not find required columns in header: {header}")
            return None, None
            
        # Extract values
        admin_password = row[password_index] if len(row) > password_index else ""
        activation_url = row[url_index] if len(row) > url_index else ""
        
        return admin_password, activation_url
        
    except Exception as e:
        print(f"Error extracting data from row: {e}")
        return None, None

def process_password_change(url, admin_password, domain_name, row_index):
    """Complete password change process: click I understand, fill password, submit, and update status"""
    driver = None
    try:
        # Validate input parameters
        if not url or not admin_password or not domain_name:
            print(f"❌ Invalid parameters: URL={url}, Password={'*' * len(admin_password) if admin_password else 'None'}, Domain={domain_name}")
            return False
            
        print(f"\n🤖 Processing {domain_name}")
        print(f"🔑 Admin Password: {admin_password}")
        print(f"🌐 URL: {url}")
        
        # Initialize browser in private/incognito mode
        driver = Driver(uc=True, incognito=True, headless=False)
        driver.maximize_window()
        
        # Navigate to activation URL
        driver.get(url)
        time.sleep(3)
        
        print(f"📄 Page loaded: {driver.title}")
        
        # Step 1: Find and click the "I understand" button
        google_confirm_selectors = [
            "input[type='submit'][name='confirm'][value='I understand']",
            "input[name='confirm'][value='I understand']",
            "input[value='I understand']",
            "input[type='submit'][id='confirm']",
            "input[id='confirm']",
            "input[class*='MK9CEd'][class*='MVpUfe']",
            "input[jsname='M2UYVd']"
        ]
        
        button_clicked = False
        for selector in google_confirm_selectors:
            try:
                confirm_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                confirm_btn.click()
                print(f"✅ 'I understand' button clicked for {domain_name}")
                button_clicked = True
                break
            except TimeoutException:
                continue
        
        if not button_clicked:
            print(f"⚠️  Could not find 'I understand' button for {domain_name}")
            return False
        
        # Wait for password change page to load
        time.sleep(3)
        print(f"📄 After I understand - Page loaded: {driver.title}")
        
        # Step 2: Fill in the password fields
        password_selectors = [
            "input[type='password']",
            "input[name*='password']",
            "input[id*='password']",
            "input[placeholder*='password']"
        ]
        
        password_inputs = []
        for selector in password_selectors:
            try:
                inputs = driver.find_elements(By.CSS_SELECTOR, selector)
                password_inputs.extend(inputs)
            except:
                continue
        
        if len(password_inputs) >= 2:
            # Fill first password field (Create password)
            password_inputs[0].clear()
            password_inputs[0].send_keys(admin_password)
            print(f"✅ First password field filled")
            
            # Fill second password field (Confirm password)
            password_inputs[1].clear()
            password_inputs[1].send_keys(admin_password)
            print(f"✅ Second password field filled")
        else:
            print(f"⚠️  Could not find password input fields")
            return False
        
        # Step 3: Click "Change password" button
        change_password_selectors = [
            "button:contains('Change password')",
            "input[value='Change password']",
            "button[type='submit']",
            ".btn-primary",
            "button:contains('Submit')"
        ]
        
        change_clicked = False
        for selector in change_password_selectors:
            try:
                if ":contains" in selector:
                    # Handle XPath for text content
                    xpath = f"//button[contains(text(), 'Change password')]"
                    change_btn = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, xpath))
                    )
                else:
                    change_btn = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                change_btn.click()
                print(f"✅ 'Change password' button clicked")
                change_clicked = True
                break
            except TimeoutException:
                continue
        
        if not change_clicked:
            print(f"⚠️  Could not find 'Change password' button")
            return False
        
        # Step 4: Update status as success after clicking "Change password"
        print(f"✅ Password change completed for {domain_name}")
        update_status_in_sheet(row_index, "success", domain_name)
        
        return True
        
    except Exception as e:
        print(f"❌ Error processing {domain_name}: {e}")
        # Update status as error
        update_status_in_sheet(row_index, "error", domain_name)
        return False
        
    finally:
        if driver:
            # Close the browser
            try:
                driver.quit()
                print(f"🌐 Browser closed for {domain_name}")
            except Exception as e:
                print(f"⚠️  Error closing browser for {domain_name}: {e}")

def update_status_in_sheet(row_index, status, domain_name=None):
    """Update status in Google Sheet via Apps Script using row index (thread-safe)"""
    with sheet_update_lock:
        try:
            apps_script_url = "https://script.google.com/macros/s/AKfycbx5HN2pQpDTJmdSAxMPJi4NtzkDtH0MPklm1i1xHH7RkXjNV4kp1R85nDs7burLGNqg/exec"
            
            data = {
                "row_index": row_index,  # Use row index instead of domain name
                "status": status
            }
            
            # Include domain name for logging purposes if provided
            if domain_name:
                data["domain"] = domain_name
            
            response = requests.post(apps_script_url, json=data)
            
            if response.status_code == 200:
                log_msg = f"✅ Status updated in sheet: Row {row_index}"
                if domain_name:
                    log_msg += f" ({domain_name})"
                log_msg += f" -> {status}"
                print(log_msg)
            else:
                print(f"⚠️  Failed to update status in sheet: {response.status_code}")
                
        except Exception as e:
            print(f"❌ Error updating status in sheet: {e}")

def process_single_domain(domain_data):
    """Process a single domain (for concurrent execution, may fetch activation link)."""
    # Extract data safely (no need for lock since we're working with immutable copies)
    domain_name, admin_password, activation_url, index, total = domain_data
    
    # Get current thread info for debugging
    thread_id = threading.current_thread().ident
    thread_name = threading.current_thread().name
    
    print(f"\n{'='*20} Thread {thread_name} ({thread_id}) Processing {index}/{total} {'='*20}")
    print(f"🏢 Domain: {domain_name}")
    print(f"🔑 Admin Password: {admin_password}")
    print(f"🌐 Activation URL: {activation_url or '[missing → will search IMAP]'}")
    
    if not admin_password:
        print(f"⚠️  Skipping {domain_name} - missing password")
        return False

    # If activation URL missing, search IMAP for this domain and update the sheet
    if not activation_url:
        print(f"🔎 IMAP search for activation link: {domain_name}")
        try:
            link = imap_find_activation_link_for_domain_single(domain_name)
        except Exception as e:
            print(f"❌ IMAP search error for {domain_name}: {e}")
            link = None
        if not link:
            print(f"❌ No activation link found for {domain_name}")
            return False
        update_activation_url_in_sheet(domain_name, link)
        activation_url = link
    
    try:
        return process_password_change(activation_url, admin_password, domain_name, index)
    except Exception as e:
        print(f"❌ Error processing {domain_name}: {e}")
        return False

def main():
    """Process with 5 concurrency: per row, fetch activation link if missing, then run Selenium and update status."""
    print("🚀 Starting Activation+Password Process (5 concurrency)")
    print("=" * 50)

    # Read data from Google Sheet (rows where status is empty, vm=v1, etc.)
    header, rows = read_google_sheet()
    
    if not header or not rows:
        print("❌ Failed to read data from Google Sheet")
        return
    
    print(f"\n📊 Processing {len(rows)} entries with 5 concurrent threads...")

    # Prepare domain data list
    domain_data_list = []
    total_rows = len(rows)
    for i, row in enumerate(rows, 1):
        if not row or len(row) < 2:
            continue
        domain_name = row[0] if row[0] else f"Entry {i}"
        admin_password, activation_url = extract_password_and_url(row, header)
        domain_data_list.append((str(domain_name), str(admin_password or ''), str(activation_url or ''), int(i), int(total_rows)))

    successful_count = 0
    failed_count = 0
    try:
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_domain = { executor.submit(process_single_domain, data): data[0] for data in domain_data_list }
            for future in as_completed(future_to_domain):
                domain_name = future_to_domain[future]
                try:
                    result = future.result()
                    if result:
                        successful_count += 1
                    else:
                        failed_count += 1
                except Exception as e:
                    print(f"❌ Exception for {domain_name}: {e}")
                    failed_count += 1
                print(f"📊 Progress: {successful_count + failed_count}/{len(domain_data_list)} completed")
    except KeyboardInterrupt:
        print("\n\n⏹️  Process interrupted by user")

    print(f"\n✅ Process completed! Results: {successful_count} successful, {failed_count} failed")
    print("=" * 50)


def _run_job_guarded():
    global _job_running
    with _job_lock:
        if _job_running:
            return False
        _job_running = True
    try:
        main()
    finally:
        with _job_lock:
            _job_running = False
    return True


class TriggerHandler(BaseHTTPRequestHandler):
    def _send_json(self, obj, status=200):
        payload = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/trigger"):
            started = False
            if not _job_running:
                t = threading.Thread(target=_run_job_guarded, daemon=True)
                t.start()
                started = True
            self._send_json({"ok": True, "started": started, "running": _job_running})
            return
        if path == "/stop":
            self._send_json({"ok": True, "stopping": True})
            def _delayed_stop():
                time.sleep(0.5)
                try:
                    if _http_server:
                        _http_server.shutdown()
                except Exception:
                    pass
                os._exit(0)
            threading.Thread(target=_delayed_stop, daemon=True).start()
            return
        if path in ("/status", "/health", "/"):
            self._send_json({"ok": True, "running": _job_running})
            return
        self._send_json({"ok": False, "error": "Not found"}, status=404)

    def log_message(self, format, *args):
        # Terse access log
        print(f"🌐 [{self.address_string()}] {format % args}")


def start_trigger_server(host="0.0.0.0", port=6969):
    global _http_server
    server = HTTPServer((host, port), TriggerHandler)
    _http_server = server
    print(f"🌐 Trigger server listening on http://{host}:{port}/trigger")
    print("   Also available: /status and /tigger")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n⏹️  Server stopped")
    finally:
        server.server_close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Activation + password processor")
    parser.add_argument("--serve", action="store_true", help="Start HTTP trigger server on port 6969")
    args = parser.parse_args()
    if args.serve:
        start_trigger_server()
    else:
        main()